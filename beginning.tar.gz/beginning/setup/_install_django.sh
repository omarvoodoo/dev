#!/bin/sh

# install django + uwsgi

PROJECT_DIR=$HOME/red

sudo apt-get install -y git python-pip python python-dev libmysqlclient-dev
sudo pip install django uwsgi pillow boto mysql-python djangorestframework django-cors-headers django-rest-swagger

sudo cp -r $PROJECT_DIR/setup/etc/init/uwsgi.conf /etc/init/
sudo cp -r $PROJECT_DIR/setup/etc/uwsgi/ /etc/uwsgi/

sudo service uwsgi restart
