#!/bin/sh

PROJECT_DIR=$HOME/red

sudo debconf-set-selections <<< 'mysql-server-5.5 mysql-server/root_password password dkssudgktpdy'
sudo debconf-set-selections <<< 'mysql-server-5.5 mysql-server/root_password_again password dkssudgktpdy'
sudo apt-get install -y mysql-server

sudo cp -r $PROJECT_DIR/setup/etc/mysql/ /etc/
sudo service mysql restart

# set db
mysql -u"root" -p"dkssudgktpdy" mysql -e "create user wisdome;"
mysql -u"root" -p"dkssudgktpdy" mysql -e "create user wisdome@localhost identified by 'dkssudgktpdy';"
mysql -u"root" -p"dkssudgktpdy" mysql -e "create user 'wisdome'@'%' identified by 'dkssudgktpdy';"
mysql -u"root" -p"dkssudgktpdy" mysql -e "create database webapp;"
mysql -u"root" -p"dkssudgktpdy" mysql -e "grant all privileges on webapp.* to wisdome@localhost;"
mysql -u"root" -p"dkssudgktpdy" mysql -e "grant all privileges on webapp.* to wisdome@'%';"
mysql -u"root" -p"dkssudgktpdy" mysql -e "grant all on *.* to 'wisdome'@'%' identified by 'dkssudgktpdy' with grant option;"
mysql -u"root" -p"dkssudgktpdy" mysql -e "flush privileges;"
