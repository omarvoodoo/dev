#!/bin/sh

nohup uwsgi /Users/kimyungyi/Documents/Projects/red/setup/etc/uwsgi/uwsgi.yungyikim.mac.ini &
