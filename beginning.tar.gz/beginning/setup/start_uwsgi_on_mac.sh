#!/bin/sh

nohup uwsgi /Users/w-macbook-03/Documents/Projects/red/setup/etc/uwsgi/uwsgi.mac.ini &
