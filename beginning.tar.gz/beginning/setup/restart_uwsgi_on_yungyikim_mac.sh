#!/bin/sh

killall -9 uwsgi
sh start_uwsgi_on_yungyikim_mac.sh
