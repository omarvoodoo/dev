#-*- coding: utf-8 -*-

from __future__ import unicode_literals
from django.contrib.auth.models import User
from django.db import models
from django.conf import settings
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager

# Create your models here.

class Vote(models.Model):
    value = models.IntegerField(null=False)
    comment = models.TextField(blank=True)
    created = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return "%d" % (self.id)

# 설문지 양식
class Survey(models.Model):
    document = models.ForeignKey('Document', related_name='survey')
    data = models.TextField(blank=True)

    def __str__(self):
        return "%d" % (self.id)

# 설문지 응답 데이터
class SurveyResponse(models.Model):
    survey = models.ForeignKey('Survey', related_name='responses')
    name = models.CharField(blank=True, max_length=100)
    email = models.CharField(blank=True, max_length=100)
    phone = models.CharField(blank=True, max_length=100)
    data = models.TextField(blank=True)

    def __str__(self):
        return "%d" % (self.id)

class Information(models.Model):
    document = models.OneToOneField('Document')
    subtitle = models.CharField(blank=True, max_length=100)
    contents = models.TextField(blank=True)
    brand_name = models.CharField(blank=True, max_length=100)
    image = models.TextField(blank=True)
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return "%d" % (self.id)

class Document(models.Model):
    owner = models.ForeignKey(settings.AUTH_USER_MODEL, related_name='documents')
    title = models.CharField(max_length=100)
    subtitle = models.CharField(blank=True, max_length=100)
    contents = models.TextField(blank=True)
    brand_name = models.CharField(blank=True, max_length=100)
    image = models.TextField(blank=True)
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now_add=True)
    limits = models.IntegerField(blank=True, null=True)
    entry_fee = models.IntegerField(blank=True, null=True)
    event_date = models.CharField(blank=True, max_length=16)
    start_time = models.CharField(blank=True, max_length=16)
    end_time = models.CharField(blank=True, max_length=16)
    place = models.CharField(max_length=32, blank=True, default='')
    place_keyword = models.CharField(max_length=32, blank=True, default='')
    place_name = models.CharField(max_length=32, blank=True, default='')
    place_address = models.CharField(max_length=100, blank=True, default='')
    place_lat = models.DecimalField(blank=True, null=True, max_digits=11, decimal_places=7)
    place_lon = models.DecimalField(blank=True, null=True, max_digits=11, decimal_places=7)
    answer_name = models.BooleanField(blank=True, default=False)
    answer_email = models.BooleanField(blank=True, default=False)
    answer_phone = models.BooleanField(blank=True, default=False)
    alert_email_d_day = models.BooleanField(blank=True, default=False)
    alert_email_d_day_before = models.BooleanField(blank=True, default=False)
    alert_email_d_day_after = models.BooleanField(blank=True, default=False)

    def __str__(self):
        return "%d - %s" % (self.id, self.title,)

class CustomUserManager(BaseUserManager):
    def create_user(self, email, department, password=None):
        """
        Creates and saves a User with the given email, date of
        birth and password.
        """
        if not email:
            raise ValueError('Users must have an email address')

        user = self.model(
            email=self.normalize_email(email),
			department=department,
        )

        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, department, password):
        """
        Creates and saves a superuser with the given email, date of
        birth and password.
        """
        user = self.create_user(email,
            password=password,
			department=department
        )
        user.is_admin = True
        user.save(using=self._db)
        return user


class CustomUser(AbstractBaseUser):
    email = models.EmailField(
        verbose_name='email address',
        max_length=255,
        unique=True,
    )
    department = models.IntegerField(default=0)
    is_active = models.BooleanField(default=True)
    is_admin = models.BooleanField(default=False)

    objects = CustomUserManager()

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = []

    def get_full_name(self):
        # The user is identified by their email address
        return self.email

    def get_short_name(self):
        # The user is identified by their email address
        return self.email

    def __str__(self):              # __unicode__ on Python 2
        return "%d - %s" % (self.id, self.email,)

    def has_perm(self, perm, obj=None):
        "Does the user have a specific permission?"
        # Simplest possible answer: Yes, always
        return True

    def has_module_perms(self, app_label):
        "Does the user have permissions to view the app `app_label`?"
        # Simplest possible answer: Yes, always
        return True

    @property
    def is_staff(self):
        "Is the user a member of staff?"
        # Simplest possible answer: All admins are staff
        return self.is_admin
