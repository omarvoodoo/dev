#-*- coding: utf-8 -*-

from django.shortcuts import render
from rest_framework import viewsets
from django.contrib.auth import get_user_model
import api.models as models
import api.serializers as serializers
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth import authenticate, login, logout
from django.core.validators import validate_email
from django import forms
import logging
import json
import base64
import httplib
import sys
import uuid
import os
from boto.s3.connection import S3Connection
from boto.s3.key import Key

AWS_STORAGE_BUCKET_NAME = 'moim-design'
AWS_ACCESS_KEY_ID = 'AKIAI3SQP32RNXYRJALA'
AWS_SECRET_ACCESS_KEY = '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'
AWS_REGION_HOST = 's3.ap-northeast-2.amazonaws.com'
conn = S3Connection(AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, host=AWS_REGION_HOST)
bucket = conn.get_bucket(AWS_STORAGE_BUCKET_NAME)

#reload(sys)
#sys.setdefaultencoding('utf-8')

# Create your views here.

User = get_user_model()
logger = logging.getLogger('command')


def uploadFile(filename, files):
    k = Key(bucket)
    k.key = filename
    k.set_contents_from_string(files.read())

    # 파일 공개
    k.set_acl('public-read')

    # 업로드 후 url 생성, 유효기간 설정(10년)
    return k.generate_url(3600*24*365*10)

@csrf_exempt
def upload(req):
    if req.method == 'POST':
        if 'file' in req.FILES:
            result = []
            for file in req.FILES.getlist('file'):
                # 'UUID + 확장자' 형식으로 파일명을 만든다
                _, fileExtension = os.path.splitext(file._name)
                filename = str(uuid.uuid1()) + fileExtension
                logger.info(filename)
                url = uploadFile(filename, file)
                url = url.split('?')[0]
                result.append(url)
            return HttpResponse(json.dumps(result))
    return HttpResponse('failed to upload file')

class VoteViewSet(viewsets.ModelViewSet):
    queryset = models.Vote.objects.all();
    serializer_class = serializers.VoteSerializer

class SurveyViewSet(viewsets.ModelViewSet):
    queryset = models.Survey.objects.all();
    serializer_class = serializers.SurveySerializer

class SurveyResponseViewSet(viewsets.ModelViewSet):
    queryset = models.SurveyResponse.objects.all();
    serializer_class = serializers.SurveyResponseSerializer

class InformationViewSet(viewsets.ModelViewSet):
    queryset = models.Information.objects.all();
    serializer_class = serializers.InformationSerializer

class DocumentSummaryViewSet(viewsets.ModelViewSet):
    queryset = models.Document.objects.all()
    serializer_class = serializers.DocumentSummarySerializer

class DocumentViewSet(viewsets.ModelViewSet):
    queryset = models.Document.objects.all()
    serializer_class = serializers.DocumentSerializer

class UserViewSet(viewsets.ModelViewSet):
    queryset = User.objects.order_by(User.USERNAME_FIELD)
    serializer_class = serializers.UserSerializer

@csrf_exempt
def getSurveyResponseFromSurveyid(request, surveyId):
    result = {}
    try:
        result['survey'] = surveyId
        result['responses'] = []
        objs = models.SurveyResponse.objects.filter(survey=surveyId)
        logger.info(objs)
        for obj in objs:
            logger.info(obj.data)
            response = {}
            response['id'] = obj.id
            response['data'] = obj.data
            logger.info(response)
            result['responses'].append(response)

        logger.info(result)
    except:
        return HttpResponse('fail', status=404)
    return HttpResponse( json.dumps(result), status=200 )

@csrf_exempt
def getSurveyFromDocid(request, documentId):
    result = {}
    try:
        survey = models.Survey.objects.get(document=documentId)
        result['id'] = survey.id
        result['document'] = survey.document_id
        if survey.data:
            result['data'] = survey.data
            logger.info(survey.data)
    except:
        return HttpResponse('fail', status=404)
    return HttpResponse( json.dumps(result), status=200 )

@csrf_exempt
def getInformationFromDocid(request, documentId):
    result = {}
    try:
        information = models.Information.objects.get(document=documentId)
        result['id'] = information.id
        result['document'] = information.document_id
        result['subtitle'] = information.subtitle
        result['contents'] = information.contents
        result['brand_name'] = information.brand_name
        result['image'] = information.image
        result['created'] = information.created.isoformat()
        result['updated'] = information.updated.isoformat()
        logger.info('result: %s' % result)
    except:
        return HttpResponse('fail', status=404)

    return HttpResponse(json.dumps(result), status=200)

@csrf_exempt
def getInfoId(request, documentId):
    result = {}
    try:
        info = models.Info.objects.get(document=documentId)
        logger.info('info: %s' % info)
        logger.info('info.id: %s' % info.id)
        result['id'] = info.id
    except:
        return HttpResponse('fail', status=404)

    return HttpResponse(json.dumps(result), status=200)

@csrf_exempt
def searchPOI(request):
    if request.body:
        try:
            data = json.loads(request.body.decode('utf-8'))

            if data and type(data).__name__ == 'dict':
                searchKeyword = data['searchKeyword']

                # 키워드의 공백을 제거한다.
                searchKeyword = searchKeyword.replace(" ", "")

                logger.info(searchKeyword)
                headers = {
                    'Accept': 'application/json',
                    'access_token': 'd9287f7e-cf72-4c16-8085-3a7bd60ea145',
                    'appKey': '7a1bac88-0ac3-3a6f-861d-8b054beb7b2b',
                    'Content-type': 'application/json charset=utf-8'
                }
                conn = httplib.HTTPSConnection('apis.skplanetx.com')
                conn.request('GET', '/tmap/pois?areaLMCode=&centerLon=&centerLat=&count=&page=&reqCoordType=&searchKeyword='+searchKeyword.encode('utf-8')+'&callback=&areaLLCode=&multiPoint=&searchtypCd=&radius=&searchType=&resCoordType=WGS84GEO&version=1', headers=headers)
                result = conn.getresponse().read()
                conn.close()

                if result == '':
                    result = {
                        'error': 1
                    }
                    result = json.dumps(result)
                logger.info(result)
                return HttpResponse(result, status=200)

        except ValueError as e:
            return HttpResponse('fail - %s' %e, status=400)
    return HttpResponse('no results')

@csrf_exempt
def signout(request):
    logout(request)
    return HttpResponse('sign out success')

@csrf_exempt
def signin(request):
    if request.user.is_authenticated():
        if request.method == 'GET':
            try:
                # 사용자 정보를 반환하자
                logger.info(request.user);

                data = {
                    'code': 0,
                    'username': request.user.get_full_name()
                }
                return HttpResponse(
                    json.dumps(data),
                    content_type = 'application/json',
                    status=200
                )
            except ValueError as e:
                return HttpResponse('sign in fail - %s' % e, status=400)
        return HttpResponse('sign in success - AreadySignIn')

    if request.method == 'POST':
        if request.body:
            try:
                data = json.loads(request.body.decode('utf-8'))

                if data and type(data).__name__ == 'dict':
                    email = data.get('email')
                    passwd = data.get('password')

                    logger.info('email:%s' % email)
                    logger.info('passwd:%s' % passwd)

                    user = authenticate(username=email, password=passwd)
                    if user is not None:
                        logger.info('user is not None')
                        if user.is_active:
                            logger.info('user.is_active')
                            login(request, user)
                            logger.info('login end')
                        else:
                            return HttpResponse('sign in fail - DisabledAccount', status=400)
                    else:
                        return HttpResponse('sign in fail - InvalidAccount', status=400)

                    logger.info('end')
                    return HttpResponse('sign in success')
            except ValueError as e:
                return HttpResponse('sign in fail - %s' %e, status=400)
    else:
        data = {
            'code': 1,
            'username': '',
            'msg': 'Unauthorized'
        }
        return HttpResponse(
            json.dumps(data),
            content_type = 'application/json',
            status=200
        )

    return HttpResponse('sign in fail', status=400)

@csrf_exempt
def signup(request):
    if request.method == 'POST':
        if request.body:
            try:
                data = json.loads(request.body.decode('utf-8'))

                if data and type(data).__name__ == 'dict':
                    email = data.get('email')
                    passwd = data.get('password')
                    department = data.get('department')

                    logger.info('email:%s' % email)
                    logger.info('passwd:%s' % passwd)
                    logger.info('department:%s' % department)

                    # 이메일 형식 체크
                    try:
                        validate_email(email)
                    except forms.ValidationError as e:
                        return HttpResponse('sign up fail - EmailValidationError', status=400)

                    if User.objects.filter(email=email).exists():
                        return HttpResponse('exists')

                    if email and passwd and department:
                        user = User.objects.create_user(
                        email=email,
                        department=department,
                        password=passwd
                        )
                        user.save()

                        return HttpResponse('sign up success')
                    #return HttpResponseRedirect('/main.html')
            except ValueError as e:
                return HttpResponse('sign up fail - %s' % e, status=400)

    return HttpResponse('sign up fail', status=400)
