#-*- coding: utf-8 -*-

from rest_framework import serializers
from django.contrib.auth import get_user_model
import api.models as models

User = get_user_model()

class UserSerializer(serializers.ModelSerializer):
    full_name = serializers.CharField(source='get_full_name', read_only=True)
    class Meta:
        model = User
        fields = ('id', User.USERNAME_FIELD, 'full_name', 'department', 'is_active')

class VoteSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Vote
        fields = (
            'id',
            'value',
            'comment',
            'created')

class SurveySerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Survey
        fields = (
            'id',
            'document',
            'data')

class SurveyResponseSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.SurveyResponse
        fields = (
            'id',
            'survey',
            'name',
            'email',
            'phone',
            'data')

class InformationSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Information
        fields = (
            'id',
            'subtitle',
            'contents',
            'brand_name',
            'image',
            'created',
            'updated',
            'document')

class DocumentSummarySerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Document
        fields = (
            'id',
            'title',
            'created',
            'updated',
            'owner')

class DocumentSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Document
        fields = (
            'id',
            'title',
            'subtitle',
            'contents',
            'brand_name',
            'image',
            'created',
            'updated',
            'limits',
            'entry_fee',
            'event_date',
            'start_time',
            'end_time',
            'place',
            'place_keyword',
            'place_name',
            'place_address',
            'place_lat',
            'place_lon',
            'answer_name',
            'answer_email',
            'answer_phone',
            'alert_email_d_day',
            'alert_email_d_day_before',
            'alert_email_d_day_after',
            'owner')
