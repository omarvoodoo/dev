mecab -d . -F "%m\t%f[0],%phl,%phr,%pb,%pw,%pC,%pc,%pn\n" -N5
