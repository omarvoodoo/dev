#!/bin/sh
cp *.bin ../../bin/dics
cp *.dic ../../bin/dics
